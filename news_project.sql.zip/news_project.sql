-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 07, 2024 at 02:39 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `news_project`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `admin_name` varchar(50) NOT NULL,
  `username` varchar(60) NOT NULL,
  `password` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `admin_name`, `username`, `password`) VALUES
(1, 'Kaustubh Gandhi', 'kaustubhgandhi10', '81dc9bdb52d04dc20036dbd8313ed055');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `id` int(60) NOT NULL,
  `category_name` varchar(100) NOT NULL,
  `post` int(10) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `category_name`, `post`) VALUES
(18, 'Entertainment', 3),
(19, 'Music', 4),
(20, 'Life', 1),
(23, 'Tech', 2),
(28, 'Horror', 1);

-- --------------------------------------------------------

--
-- Table structure for table `post`
--

CREATE TABLE `post` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `category` int(10) NOT NULL,
  `post_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `author` int(10) NOT NULL,
  `post_img` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `post`
--

INSERT INTO `post` (`id`, `title`, `description`, `category`, `post_date`, `author`, `post_img`) VALUES
(39, 'Tesla’s Cybertruck fiasco cost Elon Musk $768 million in a single day', 'Last week, news broke that James Dean will star in a new movie—64 years after his death. A production company called Magic City got the rights to Dean’s image from the late actor’s estate and plans to bring him to the silver screen again thanks to the wonder (or terror) of CGI. Now, Dean, or the digitally resurrected version of Dean or whatever, will play the second lead in a Vietnam War movie called Finding Jack, with a living actor standing in as his voice.\r\n\r\nUnsurprisingly, the announcement inspired a wave of immediate backlash around Hollywood. Chris Evans called it “awful” and “shameful,” and Elijah Wood said, simply, “NOPE.” But it turns out the intense reaction was surprising to at least one person: Magic City’s Anton Ernst, the Finding Jack director.\r\n\r\nErnst told the Hollywood Reporter in a new interview that he’s gotten “positive feedback” about the movie and that the Dean estate has been “supportive,” saying it will inspire “a whole new generation of filmgoers to be aware of James Dean.” He didn’t see the overwhelming negativity coming.', 20, '2024-03-14 06:51:41', 1, 'banner-img-1.jpg'),
(40, 'What UK political parties are promising in the 2019 general election', 'Last week, news broke that James Dean will star in a new movie—64 years after his death. A production company called Magic City got the rights to Dean’s image from the late actor’s estate and plans to bring him to the silver screen again thanks to the wonder (or terror) of CGI. Now, Dean, or the digitally resurrected version of Dean or whatever, will play the second lead in a Vietnam War movie called Finding Jack, with a living actor standing in as his voice.\r\n\r\nUnsurprisingly, the announcement inspired a wave of immediate backlash around Hollywood. Chris Evans called it “awful” and “shameful,” and Elijah Wood said, simply, “NOPE.” But it turns out the intense reaction was surprising to at least one person: Magic City’s Anton Ernst, the Finding Jack director.\r\n\r\nErnst told the Hollywood Reporter in a new interview that he’s gotten “positive feedback” about the movie and that the Dean estate has been “supportive,” saying it will inspire “a whole new generation of filmgoers to be aware of James Dean.” He didn’t see the overwhelming negativity coming.', 17, '2024-03-14 11:36:15', 1, '11-485x360.jpg'),
(41, 'Lights that warn planes of obstacles were exposed to Open Internet', 'Last week, news broke that James Dean will star in a new movie—64 years after his death. A production company called Magic City got the rights to Dean’s image from the late actor’s estate and plans to bring him to the silver screen again thanks to the wonder (or terror) of CGI. Now, Dean, or the digitally resurrected version of Dean or whatever, will play the second lead in a Vietnam War movie called Finding Jack, with a living actor standing in as his voice.\r\n\r\nUnsurprisingly, the announcement inspired a wave of immediate backlash around Hollywood. Chris Evans called it “awful” and “shameful,” and Elijah Wood said, simply, “NOPE.” But it turns out the intense reaction was surprising to at least one person: Magic City’s Anton Ernst, the Finding Jack director.\r\n\r\nErnst told the Hollywood Reporter in a new interview that he’s gotten “positive feedback” about the movie and that the Dean estate has been “supportive,” saying it will inspire “a whole new generation of filmgoers to be aware of James Dean.” He didn’t see the overwhelming negativity coming.', 23, '2024-03-14 11:35:58', 1, '5-485x360.jpg'),
(42, 'What’s the point of ‘Charlie’s Angels’ without Sam Rockwell dancing?', 'Last week, news broke that James Dean will star in a new movie—64 years after his death. A production company called Magic City got the rights to Dean’s image from the late actor’s estate and plans to bring him to the silver screen again thanks to the wonder (or terror) of CGI. Now, Dean, or the digitally resurrected version of Dean or whatever, will play the second lead in a Vietnam War movie called Finding Jack, with a living actor standing in as his voice.\r\n\r\nUnsurprisingly, the announcement inspired a wave of immediate backlash around Hollywood. Chris Evans called it “awful” and “shameful,” and Elijah Wood said, simply, “NOPE.” But it turns out the intense reaction was surprising to at least one person: Magic City’s Anton Ernst, the Finding Jack director.\r\n\r\nErnst told the Hollywood Reporter in a new interview that he’s gotten “positive feedback” about the movie and that the Dean estate has been “supportive,” saying it will inspire “a whole new generation of filmgoers to be aware of James Dean.” He didn’t see the overwhelming negativity coming.', 18, '2024-03-14 11:36:38', 1, '29-485x360.jpg'),
(43, 'Exploring the origins of punk across America with Kid Karate and Bushmills', 'Last week, news broke that James Dean will star in a new movie—64 years after his death. A production company called Magic City got the rights to Dean’s image from the late actor’s estate and plans to bring him to the silver screen again thanks to the wonder (or terror) of CGI. Now, Dean, or the digitally resurrected version of Dean or whatever, will play the second lead in a Vietnam War movie called Finding Jack, with a living actor standing in as his voice.\r\n\r\nUnsurprisingly, the announcement inspired a wave of immediate backlash around Hollywood. Chris Evans called it “awful” and “shameful,” and Elijah Wood said, simply, “NOPE.” But it turns out the intense reaction was surprising to at least one person: Magic City’s Anton Ernst, the Finding Jack director.\r\n\r\nErnst told the Hollywood Reporter in a new interview that he’s gotten “positive feedback” about the movie and that the Dean estate has been “supportive,” saying it will inspire “a whole new generation of filmgoers to be aware of James Dean.” He didn’t see the overwhelming negativity coming.', 19, '2024-03-14 11:37:04', 1, '34-485x360.jpg'),
(44, 'How Omni accidentally became the best post-punk band in America', 'Last week, news broke that James Dean will star in a new movie—64 years after his death. A production company called Magic City got the rights to Dean’s image from the late actor’s estate and plans to bring him to the silver screen again thanks to the wonder (or terror) of CGI. Now, Dean, or the digitally resurrected version of Dean or whatever, will play the second lead in a Vietnam War movie called Finding Jack, with a living actor standing in as his voice.\r\n\r\nUnsurprisingly, the announcement inspired a wave of immediate backlash around Hollywood. Chris Evans called it “awful” and “shameful,” and Elijah Wood said, simply, “NOPE.” But it turns out the intense reaction was surprising to at least one person: Magic City’s Anton Ernst, the Finding Jack director.\r\n\r\nErnst told the Hollywood Reporter in a new interview that he’s gotten “positive feedback” about the movie and that the Dean estate has been “supportive,” saying it will inspire “a whole new generation of filmgoers to be aware of James Dean.” He didn’t see the overwhelming negativity coming.', 19, '2024-03-14 11:37:22', 1, '35-1068x712.jpg'),
(45, 'The 2020 grammy nominations are really trying to be relevant', 'Last week, news broke that James Dean will star in a new movie—64 years after his death. A production company called Magic City got the rights to Dean’s image from the late actor’s estate and plans to bring him to the silver screen again thanks to the wonder (or terror) of CGI. Now, Dean, or the digitally resurrected version of Dean or whatever, will play the second lead in a Vietnam War movie called Finding Jack, with a living actor standing in as his voice.\r\n\r\nUnsurprisingly, the announcement inspired a wave of immediate backlash around Hollywood. Chris Evans called it “awful” and “shameful,” and Elijah Wood said, simply, “NOPE.” But it turns out the intense reaction was surprising to at least one person: Magic City’s Anton Ernst, the Finding Jack director.\r\n\r\nErnst told the Hollywood Reporter in a new interview that he’s gotten “positive feedback” about the movie and that the Dean estate has been “supportive,” saying it will inspire “a whole new generation of filmgoers to be aware of James Dean.” He didn’t see the overwhelming negativity coming.', 19, '2024-03-14 11:37:37', 1, '32-485x360.jpg'),
(46, 'Noel Gallagher says Liam’s tweets are the reason Oasis won’t reunite', 'Last week, news broke that James Dean will star in a new movie—64 years after his death. A production company called Magic City got the rights to Dean’s image from the late actor’s estate and plans to bring him to the silver screen again thanks to the wonder (or terror) of CGI. Now, Dean, or the digitally resurrected version of Dean or whatever, will play the second lead in a Vietnam War movie called Finding Jack, with a living actor standing in as his voice.\r\n\r\nUnsurprisingly, the announcement inspired a wave of immediate backlash around Hollywood. Chris Evans called it “awful” and “shameful,” and Elijah Wood said, simply, “NOPE.” But it turns out the intense reaction was surprising to at least one person: Magic City’s Anton Ernst, the Finding Jack director.\r\n\r\nErnst told the Hollywood Reporter in a new interview that he’s gotten “positive feedback” about the movie and that the Dean estate has been “supportive,” saying it will inspire “a whole new generation of filmgoers to be aware of James Dean.” He didn’t see the overwhelming negativity coming.', 19, '2024-03-14 11:37:56', 1, '33-485x360.jpg'),
(47, 'These striking photos capture the future of human flight', 'Last week, news broke that James Dean will star in a new movie—64 years after his death. A production company called Magic City got the rights to Dean’s image from the late actor’s estate and plans to bring him to the silver screen again thanks to the wonder (or terror) of CGI. Now, Dean, or the digitally resurrected version of Dean or whatever, will play the second lead in a Vietnam War movie called Finding Jack, with a living actor standing in as his voice.\r\n\r\nUnsurprisingly, the announcement inspired a wave of immediate backlash around Hollywood. Chris Evans called it “awful” and “shameful,” and Elijah Wood said, simply, “NOPE.” But it turns out the intense reaction was surprising to at least one person: Magic City’s Anton Ernst, the Finding Jack director.\r\n\r\nErnst told the Hollywood Reporter in a new interview that he’s gotten “positive feedback” about the movie and that the Dean estate has been “supportive,” saying it will inspire “a whole new generation of filmgoers to be aware of James Dean.” He didn’t see the overwhelming negativity coming.', 18, '2024-03-14 11:38:20', 1, '28-485x360.jpg'),
(48, '‘Heathers’ is still the best dark comedy about high school hell', 'Last week, news broke that James Dean will star in a new movie—64 years after his death. A production company called Magic City got the rights to Dean’s image from the late actor’s estate and plans to bring him to the silver screen again thanks to the wonder (or terror) of CGI. Now, Dean, or the digitally resurrected version of Dean or whatever, will play the second lead in a Vietnam War movie called Finding Jack, with a living actor standing in as his voice.\r\n\r\nUnsurprisingly, the announcement inspired a wave of immediate backlash around Hollywood. Chris Evans called it “awful” and “shameful,” and Elijah Wood said, simply, “NOPE.” But it turns out the intense reaction was surprising to at least one person: Magic City’s Anton Ernst, the Finding Jack director.\r\n\r\nErnst told the Hollywood Reporter in a new interview that he’s gotten “positive feedback” about the movie and that the Dean estate has been “supportive,” saying it will inspire “a whole new generation of filmgoers to be aware of James Dean.” He didn’t see the overwhelming negativity coming.', 18, '2024-03-14 11:38:35', 1, '27-485x360.jpg'),
(49, 'Artists used deepfake tech to tell alternate moon landing history', 'Last week, news broke that James Dean will star in a new movie—64 years after his death. A production company called Magic City got the rights to Dean’s image from the late actor’s estate and plans to bring him to the silver screen again thanks to the wonder (or terror) of CGI. Now, Dean, or the digitally resurrected version of Dean or whatever, will play the second lead in a Vietnam War movie called Finding Jack, with a living actor standing in as his voice.\r\n\r\nUnsurprisingly, the announcement inspired a wave of immediate backlash around Hollywood. Chris Evans called it “awful” and “shameful,” and Elijah Wood said, simply, “NOPE.” But it turns out the intense reaction was surprising to at least one person: Magic City’s Anton Ernst, the Finding Jack director.\r\n\r\nErnst told the Hollywood Reporter in a new interview that he’s gotten “positive feedback” about the movie and that the Dean estate has been “supportive,” saying it will inspire “a whole new generation of filmgoers to be aware of James Dean.” He didn’t see the overwhelming negativity coming.', 23, '2024-03-14 11:39:02', 1, '4-485x360.jpg'),
(50, 'Trump could hit France with more tariffs in battle over taxes on big tech', 'Last week, news broke that James Dean will star in a new movie—64 years after his death. A production company called Magic City got the rights to Dean’s image from the late actor’s estate and plans to bring him to the silver screen again thanks to the wonder (or terror) of CGI. Now, Dean, or the digitally resurrected version of Dean or whatever, will play the second lead in a Vietnam War movie called Finding Jack, with a living actor standing in as his voice.\r\n\r\nUnsurprisingly, the announcement inspired a wave of immediate backlash around Hollywood. Chris Evans called it “awful” and “shameful,” and Elijah Wood said, simply, “NOPE.” But it turns out the intense reaction was surprising to at least one person: Magic City’s Anton Ernst, the Finding Jack director.\r\n\r\nErnst told the Hollywood Reporter in a new interview that he’s gotten “positive feedback” about the movie and that the Dean estate has been “supportive,” saying it will inspire “a whole new generation of filmgoers to be aware of James Dean.” He didn’t see the overwhelming negativity coming.', 24, '2024-03-14 07:14:17', 1, '22-485x360.jpg'),
(51, 'This is how insurance is changing for gig workers and freelancers', 'Last week, news broke that James Dean will star in a new movie—64 years after his death. A production company called Magic City got the rights to Dean’s image from the late actor’s estate and plans to bring him to the silver screen again thanks to the wonder (or terror) of CGI. Now, Dean, or the digitally resurrected version of Dean or whatever, will play the second lead in a Vietnam War movie called Finding Jack, with a living actor standing in as his voice.\r\n\r\nUnsurprisingly, the announcement inspired a wave of immediate backlash around Hollywood. Chris Evans called it “awful” and “shameful,” and Elijah Wood said, simply, “NOPE.” But it turns out the intense reaction was surprising to at least one person: Magic City’s Anton Ernst, the Finding Jack director.\r\n\r\nErnst told the Hollywood Reporter in a new interview that he’s gotten “positive feedback” about the movie and that the Dean estate has been “supportive,” saying it will inspire “a whole new generation of filmgoers to be aware of James Dean.” He didn’t see the overwhelming negativity coming.', 26, '2024-03-17 20:16:08', 1, '19-1068x710.jpg'),
(52, 'hfhfffgd', 'vjhvhjjvjhhfhgcgcg', 28, '2024-03-20 01:16:50', 1, '4-485x360.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `id` int(11) NOT NULL,
  `website_name` varchar(50) NOT NULL,
  `logo` varchar(100) NOT NULL,
  `footer_desc` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `website_name`, `logo`, `footer_desc`) VALUES
(1, 'News Website', 'FIksxMXVQAErl37.png', '© Copyright 2024 News | Powered by Yahoo Baba News');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `full_name` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `full_name`, `username`, `password`) VALUES
(1, 'Kaustubh Gandhi', 'kaustubh_gandhi', '81dc9bdb52d04dc20036dbd8313ed055'),
(5, 'Yahoo Baba', 'yahoobaba01', '81dc9bdb52d04dc20036dbd8313ed055');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `post`
--
ALTER TABLE `post`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `id` int(60) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `post`
--
ALTER TABLE `post`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=53;

--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
